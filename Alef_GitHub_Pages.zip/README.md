# Alef — Иврит с нуля

Статический учебный сайт. Для публикации через GitHub Pages откройте Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save.

Откройте `index.html` локально или разместите на GitHub Pages.
